
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
public class Visitor3 extends JFrame  implements ActionListener
{
	JLabel l1,l2,l3;
	JTextField t1;
	JButton b1,b2;
	
	Visitor3()
	{
                l2=new JLabel("Search Member Dtails");
		l2.setFont(new Font("Safari",Font.BOLD,20));
		l1=new JLabel("Member Name");
                l3=new JLabel("User Name",new ImageIcon(ClassLoader.getSystemResource("image//com.jpg")),10);	
		t1=new JTextField(20);
				
		b1=new JButton("Search");
		b2=new JButton("Clear");

		setLayout(null);
		 l2.setBounds(60,20,300,20);            
	        l1.setBounds(60,60,200,20);	t1.setBounds(220,60,150,20);              
		l3.setBounds(0,0,404040400,400);
		b1.setBounds(60,100,80,20);	// b2.setBounds(220,100,80,20);






	//	p1=new JPanel();	
	
	//	p1.setLayout(new GridLayout(7,2));
		add(l1); add(t1); add(l2);  
		add(b1); add(b2);add(l3);

	//	setLayout(new BorderLayout());
	//	add(l,BorderLayout.NORTH);
	//	add(p1,BorderLayout.CENTER);

		setTitle("Seq");
		setVisible(true);
		setSize(400,250);
		setLocation(10,100);
		b1.addActionListener(this);
	}
	public void actionPerformed(ActionEvent ae)
	{ 
		String temp=ae.getActionCommand();
		if(temp.equals("Search"))
		{
		String onm=t1.getText();
		new s2(onm).setVisible(true);
}
}
	public static void main(String a[])
	{
		new Visitor3();
	}
}
