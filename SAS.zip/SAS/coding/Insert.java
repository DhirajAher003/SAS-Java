import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class Insert extends JFrame implements ActionListener
{
        JRadioButton r1,r2,r3,r4,r5,r6;
        ButtonGroup bg;
	JLabel l1,l2;
        JButton b1,b2;
        Insert()
        {
                b1=new JButton("Next",new ImageIcon(ClassLoader.getSystemResource("image//next.png")));
		b2=new JButton("Back",new ImageIcon(ClassLoader.getSystemResource("image//back.png")));
		l1=new JLabel("Select The Option");
                l1.setFont(new Font("Serif",Font.BOLD,20));
		l2=new JLabel("",new ImageIcon(ClassLoader.getSystemResource("image//com.jpg")),10);		
		
                bg=new ButtonGroup();

                r1=new JRadioButton("Owner & Flat Record");
                bg.add(r1);
                r2=new JRadioButton("Security Record");
                bg.add(r2);
                r3=new JRadioButton("Rule");
                bg.add(r3);
                r4=new JRadioButton("Maintainancs Record");
                bg.add(r4);
                r5=new JRadioButton("Chairman Record");
                bg.add(r5);
                r6=new JRadioButton("Renter Record");
                bg.add(r6);


			    //(60,20,250,20);
		
		setLayout(null);
		l1.setBounds(60,20,200,20);	
		r1.setBounds(60,60,200,20);
		r2.setBounds(60,100,200,20);
		r3.setBounds(60,140,200,20);
		r4.setBounds(60,180,200,20);
		r5.setBounds(60,220,200,20);
		r6.setBounds(60,260,200,20);
		b1.setBounds(60,300,100,20); b2.setBounds(170,300,100,20);
 		l2.setBounds(00,0,500,500);

               //setLayout(new GridLayout(7,1));
                add(r1); add(r2); add(r3); add(r4);
		add(r5); add(r6); add(b1); add(l1);add(b2);
		add(l2);
                setVisible(true);
                setSize(500,500);
                setLocation(200,100);
                setTitle("Insert");
		
		r1.setSelected(true);
		b1.addActionListener(this);
		b2.addActionListener(this);

        }
	public void actionPerformed(ActionEvent ae)
	{
		String temp=ae.getActionCommand();
		if(temp.equals("Next"))
		{	if(r1.isSelected())
			new Flat().setVisible(true);
			 this.dispose();
			if(r2.isSelected())
			new Sequrity().setVisible(true);
			 this.dispose();
			if(r3.isSelected())
			new Rule().setVisible(true);
			 this.dispose();
		        if(r5.isSelected())
			new Chairman().setVisible(true);		
			 this.dispose();
			if(r6.isSelected())
			new Rent().setVisible(true);	
			 this.dispose();
			if(r4.isSelected())
			new IMaintenanace().setVisible(true);	
			 this.dispose();
		}
		if(temp.equals("Back"))	
		{
			new Admin().setVisible(true);
			this.dispose();
		}
	}
        public static void main(String a[])
        {
                new Insert();
        }
}
                            
