import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class Update_Security extends JFrame implements ActionListener
{
	JButton b1,b2;
     	JTextField t1,t2;
	JLabel l1,l2,l3,l4,l20;
	Choice shift;
	JRadioButton r1,r2;
	ButtonGroup bg;

	Update_Security()
	{
	 	l1 =new JLabel("Security Id.: ");
		l2 =new JLabel("Sallary : ");
		l3 =new JLabel("Sec. Shift ");
		l4 =new JLabel("Update Security Detail");
		l4.setFont(new Font("Serif",Font.BOLD,20));		
		t1=new JTextField();
		t2=new JTextField();
		l20=new JLabel("",new ImageIcon(ClassLoader.getSystemResource("image//com.jpg")),10);				

		bg=new ButtonGroup();
		r1=new JRadioButton("DAY");
		bg.add(r1);
		r2=new JRadioButton("NIGHT");
		bg.add(r2);		
	
		
		/*shift = new Choice();
		shift.add("Day");
		shift.add("Night");
		shift.add("Other");*/
		
		b1 = new JButton("Update",new ImageIcon(ClassLoader.getSystemResource("image//insert.png")));
		b2 = new JButton("Clear",new ImageIcon(ClassLoader.getSystemResource("image//clear.png")));
	
		add(l1);	add(l2);	add(l3);	add(l4);	add(r1); add(r2);
		add(t1);	add(t2);	
				add(b1);	add(b2);	add(l20);
		setLayout(null);
		l1.setBounds(50,70,200,30);	t1.setBounds(210,60,150,30);
		l2.setBounds(50,130,200,30);	t2.setBounds(210,120,150,30);
		l3.setBounds(50,180,200,30);	r1.setBounds(210,170,80,30); r2.setBounds(300,170,80,30);
		b1.setBounds(50,290,110,27);	b2.setBounds(210,290,110,27);
		l4.setBounds(50,10,300,30);	l20.setBounds(0,0,500,500);
		setTitle("Update Security Detail");
		setVisible(true);
		setSize(450,400);
		setLocation(250,300);

		r1.setSelected(true);
		b1.addActionListener(this);
		b2.addActionListener(this);

		
		}
		public void actionPerformed(ActionEvent ae)
	{       
		
		
		String shift=null;
		String temp=ae.getActionCommand();
		if(temp.equals("Update"))
		{
		int sid=Integer.parseInt(t1.getText());	
		int sal=Integer.parseInt(t2.getText());
		if(r1.isSelected())	
			shift="Day";
		else
			shift="Night";
		Connection con;
		PreparedStatement ps;
		ResultSet rs;
		int i=0;
		try
		{			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		String path="D:\\ty file\\Projects\\Society Administration\\Database.mdb";
		String url="jdbc:ucanaccess://"+path;
		con=DriverManager.getConnection(url); 	
			ps=con.prepareStatement("update  sequrity set sal=?,shift=? where sid=?");
			ps.setInt(3,sid);
			ps.setString(2,shift);
			ps.setInt(1,sal);
			i=ps.executeUpdate();
			if(i==1)
			{
				JOptionPane.showMessageDialog(null," Sequrity Record is Updated","Sequrity",JOptionPane.INFORMATION_MESSAGE);
			}		
			con.close();
		}
		catch(Exception e)
		{
			String s=(e.toString() + e.getMessage());
			JOptionPane.showMessageDialog(null,s,"Error",JOptionPane.ERROR_MESSAGE);	
		}
		}
		if(temp.equals("Clear"))
                {
                        t1.setText("");
                        t2.setText("");
                        
                        
                }

	}
	public static void main(String a[])
	{
		new Update_Security();
	}	
}
