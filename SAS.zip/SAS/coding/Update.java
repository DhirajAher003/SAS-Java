import java.awt.*;
import  javax.swing.*;
import java.awt.event.*;
public class Update extends JFrame implements ActionListener
{
	JRadioButton r1,r2;
	ButtonGroup bg;
	JButton b1,b2;
	JLabel l1,l2;
	
	Update()
	{	
		bg = new ButtonGroup();
		r1 = new JRadioButton("Update Vehicle Record");
		bg.add(r1);
	
		r2 = new JRadioButton("Update Security Record");
                bg.add(r2);
		b2=new JButton("Back",new ImageIcon(ClassLoader.getSystemResource("image//back.png")));	
		b1 = new JButton("Next",new ImageIcon(ClassLoader.getSystemResource("image//next.png")));
		l1 = new JLabel("Select Option To Update The Record ");
		l1.setFont(new Font("Serif",Font.BOLD,20));
		l2=new JLabel("",new ImageIcon(ClassLoader.getSystemResource("image//com.jpg")),10);
		setLayout(null);
	//	add(l2);
		add(r2);	add(b2);	add(b1);	add(l1);	add(l2);
		l1.setBounds(20,20,450,20);
		r1.setBounds(100,90,200,20);
		 r2.setBounds(100,130,200,20);
		b1.setBounds(100,210,110,30); b2.setBounds(250,210,110,30);
		l2.setBounds(0,0,400,400);
		setTitle("Update");
		setVisible(true);
		setSize(400,400);
		setLocation(100,100);
		r1.setSelected(true);
		b1.addActionListener(this);
		b2.addActionListener(this);
//		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}
		public void actionPerformed(ActionEvent ae)
		{	String temp1=null;
		//	if(r1.isSelected())
		
			
			String temp=ae.getActionCommand();
			if(temp.equals("Next"))
			{
				//  if(r1.isSelected())
				//	new Update_vehicle().setVisible(true);
				  if(r2.isSelected())
					new Update_Security().setVisible(true);
			}
		if(temp.equals("Back"))	
		{
			new Admin().setVisible(true);
			this.dispose();
		}
		}
	public static void main(String a[])
	{
		new Update();
	}
}
