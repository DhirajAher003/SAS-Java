import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class IMaintenanace extends JFrame implements ActionListener
{

	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l20;
	JTextField t1,t2,t3,t4,t5,t6,t7,t8,t9;
	JButton b1,b2,b3,b4,b5,b6;
	DateButton t_date;	
	IMaintenanace()
	{	l1=new JLabel("Maintenance Id");
	//	l.setFont(new Font("Serif",Font.BOLD,20));
		l2=new JLabel("Maintenance Date");
		l3= new JLabel("Light Bill ");
		 l4 = new JLabel("Water Bill ");
		 l5 = new JLabel("Security Bill ");
		 l6 = new JLabel("Cleaning Bill ");
		 l7 = new JLabel("Other Bill ");
		 l8 = new JLabel("Total Bill ");
		 l9 = new JLabel("Insert Maintenance Value "); l9.setFont(new Font("Serif",Font.BOLD,20));

		 l10= new JLabel("----------------------------------------------------");
		l11=new JLabel("Flat no");
		l20=new JLabel("",new ImageIcon(ClassLoader.getSystemResource("image//men.jpg")),10);				
		t1 = new JTextField();		
		//t2 = new JTextField();
		t3 = new JTextField();
		t4 = new JTextField();
		t5 = new JTextField();
		t6 = new JTextField();
		t7=new JTextField();
		t8= new JTextField();
		t9=new JTextField();	
		b1 = new JButton("Total");
		b2 = new JButton("Print");
		b3 = new JButton("Calculator");
		b4= new JButton("Submit");
		b5=new JButton("Clear");
		b6=new JButton("Back");
		t_date = new DateButton();
		add(l1);	add(t1);
		 add(l2);	add(t_date);//add(t2);
		 add(l3);	add(t3);	
		 add(l4); 	add(t4);
		 add(l5);  	add(t5);
		 add(l6);  	add(t6);
		add(b1); 	add(b2);add(l11); add(t9);	add(b3);
		add(l7);	add(l8);
		add(l9);	add(l10);add(t7);add(t8); add(b4);add(b5);add(b6);
		setLayout(null); add(l20);
		
		l1.setBounds(100,70,150,35);	t1.setBounds(270,70,150,30);
		l2.setBounds(100,120,150,35);	t_date.setBounds(270,120,150,30);
		l11.setBounds(100,170,150,35);	t9.setBounds(270,170,150,30);
		l3.setBounds(100,220,150,35);	t3.setBounds(270,220,150,30);
		l4.setBounds(100,270,150,35);	t4.setBounds(270,270,150,30);
		l5.setBounds(100,320,150,35);	t5.setBounds(270,320,150,30);
	
		l6.setBounds(100,370,150,35);	t6.setBounds(270,370,150,30);
		l7.setBounds(100,420,150,35);	t7.setBounds(270,420,150,30);
		l8.setBounds(100,480,150,35);	t8.setBounds(270,480,150,30);

		b1.setBounds(425,480,80,30);	b4.setBounds(425,520,80,30);
		b2.setBounds(100,520,80,30);	b3.setBounds(270,520,110,30);
		b5.setBounds(100,560,80,30);	b6.setBounds(270,560,80,30);
	
		l9.setBounds(150,30,300,27);	
		l10.setBounds(90,450,500,15);	l20.setBounds(0,0,600,600);

		setTitle("Insert Maintenance");
		
		setVisible(true);
		setSize(600,640);
		setLocation(100,100);
	
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		b4.addActionListener(this);
		b5.addActionListener(this);
		b6.addActionListener(this);

		//this.setDefaultCloseOperation(EXIT_ON_CLOSE);

		Connection con;
		Statement s;
		ResultSet rs;
		int max=0;	
		try
		{
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			String path="D:\\ty file\\Projects\\Society Administration\\Database.mdb";
			String url="jdbc:ucanaccess://"+path;
			con=DriverManager.getConnection(url); 			
	
			s=con.createStatement();
			rs=s.executeQuery("select max(mid)from IMaintenance");
			if(rs.next())
			{
				max=rs.getInt(1);
			}
			con.close();
		}
		catch(Exception e){}
		max=max+1;
		t1.setText(Integer.toString(max));


	}

	public void actionPerformed(ActionEvent ae)
	{
		Connection con;
		PreparedStatement ps;
		ResultSet rs;

		String temp=ae.getActionCommand();
		 if(temp.equals("Total"))
               { 

		//String rule=a1.getText();
		int    id= Integer.parseInt(t1.getText());
		String date=t_date.getText();
		int lt_bill=Integer.parseInt(t3.getText());
		int wtr_bill=Integer.parseInt(t4.getText());
		int sec_bill=Integer.parseInt(t5.getText());
		int cl_bill=Integer.parseInt(t6.getText());
		int otr_bill=Integer.parseInt(t7.getText());
		int fno=Integer.parseInt(t9.getText());	
		
		int total = lt_bill+wtr_bill+sec_bill+cl_bill+otr_bill;
		 
		
	
		t8.setText(Float.toString(total));
	}	
	//	JOptionPane.showMessageDialog(null,"calculate total successfully","Maintenanace",JOptionPane.INFORMATION_MESSAGE);
//		temp=ae.getActionCommand();	
		int i=0;
		
			if(temp.equals("Submit"))
			{
			int    id= Integer.parseInt(t1.getText());
                String date=t_date.getText();
                int lt_bill=Integer.parseInt(t3.getText());
                int wtr_bill=Integer.parseInt(t4.getText());
                int sec_bill=Integer.parseInt(t5.getText());
                int cl_bill=Integer.parseInt(t6.getText());
                int otr_bill=Integer.parseInt(t7.getText());
                int fno=Integer.parseInt(t9.getText());
		int total = lt_bill+wtr_bill+sec_bill+cl_bill+otr_bill;
			try
			{
				Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
				String path="D:\\ty file\\Projects\\Society Administration\\Database.mdb";
				String url="jdbc:ucanaccess://"+path;
				con=DriverManager.getConnection(url); 	
				ps=con.prepareStatement("insert into IMaintenance values(?,?,?,?,?,?,?,?,?)");
				ps.setInt(1,id);
				ps.setString(2,date);
				ps.setInt(3,lt_bill);	
				ps.setInt(4,wtr_bill);
				ps.setInt(5,sec_bill);
				ps.setInt(6,cl_bill);
				ps.setInt(7,otr_bill);
				ps.setInt(8,total);
				ps.setInt(9,fno);

				i=ps.executeUpdate();
				if(i==1)
				{
					JOptionPane.showMessageDialog(null,"New IMaintenance detail is inserted","Maintenanace",JOptionPane.INFORMATION_MESSAGE);
				}			




				con.close();	
			}
			catch (Exception e) 
			{
				String s=(e.toString() + e.getMessage());	
			JOptionPane.showMessageDialog(null,s,"Error",JOptionPane.ERROR_MESSAGE);	
			}
			}		
		
			if(temp.equals("Clear"))
			{
				t2.setText("");t3.setText("");
				t4.setText("");t5.setText("");t6.setText("");t7.setText("");t8.setText("");//.setText("");
			}
			if(temp.equals("Print"))
			{
				JOptionPane.showMessageDialog(null,"Printer is not connected !!","Maintenanace",JOptionPane.INFORMATION_MESSAGE);
			}
			if(temp.equals("Calculator"))
			{
				JOptionPane.showMessageDialog(null,"use OS inbuilt Calculator","Maintenanace",JOptionPane.INFORMATION_MESSAGE);
			}
			if(temp.equals("Back"))	
		{
			new Insert().setVisible(true);
			this.dispose();
		}


		
	}



	
	
	

	public static void main(String a[])
	{
		new IMaintenanace();
		
	}
}
	

