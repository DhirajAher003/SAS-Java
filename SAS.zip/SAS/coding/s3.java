import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.sql.*;
import java.io.*;
import javax.swing.table.*;

public class s3 extends JFrame
{
	JPanel p;
	JFrame f;
	s3(String n)
	{
		f=new JFrame();
		try
		{			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		String path="D:\\ty file\\Projects\\Society Administration\\Database.mdb";
		String url="jdbc:ucanaccess://"+path;
		con=DriverManager.getConnection(url); 	
			con.setAutoCommit(false);
			PreparedStatement ps1=con.prepareStatement("select * from rent where rname=?");
			ps1.setString(1,n);
			ResultSet rs=ps1.executeQuery();
			con.commit();
			JTable  myTable = new JTable(9,9);
			int j=0,li_row=1;
			myTable.setValueAt("Id",0,0);
			myTable.setValueAt("Name",0,1);
			myTable.setValueAt("Email",0,2);
			myTable.setValueAt("Mobile",0,3);
			myTable.setValueAt("Landline",0,4);
			myTable.setValueAt("Members",0,5);
			myTable.setValueAt("Duration",0,6);
			myTable.setValueAt("Date",0,7);
			myTable.setValueAt("OwnerId",0,8);


			while(rs.next())
			{
				myTable.setValueAt(rs.getInt(1),li_row,0);
				myTable.setValueAt(rs.getString(2),li_row,1);
				myTable.setValueAt(rs.getString(3),li_row,2);		
				myTable.setValueAt(rs.getString(4),li_row,3);   
				//double f=rs.getDouble(5);
                              	//String d =""+f;
				//myTable.setValueAt(f,li_row,4);
				myTable.setValueAt(rs.getString(5),li_row,4);  
				myTable.setValueAt(rs.getInt(6),li_row,5);  
				 myTable.setValueAt(rs.getString(7),li_row,6);
				 myTable.setValueAt(rs.getInt(8),li_row,7);
				 myTable.setValueAt(rs.getInt(9),li_row,8);

				li_row++;
			}	
			JScrollPane jsp=new JScrollPane(myTable,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
			p=new JPanel();
			p.add(jsp);
			f.setLayout(new BorderLayout());
			f.add(p,BorderLayout.CENTER);
			f.setSize(600,600);
			f.setVisible(true);
//			f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		}
		catch(Exception e){}
	}
	public static void main(String a[])
	{
	new s3();
	}
}
