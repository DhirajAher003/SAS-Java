import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
public class Sequrity extends JFrame implements ActionListener
{
	JLabel l,l1,l2,l3,l4,l5,l6,l20;
	JTextField t1,t2,t4,t6;
	TextArea t3;
	JRadioButton r1,r2;
	JButton b1,b2;
	JPanel p1;
	ButtonGroup bg;

	Sequrity()
	{

		bg=new ButtonGroup();
		r1=new JRadioButton("DAY");
		bg.add(r1);
		r2=new JRadioButton("NIGHT");
		bg.add(r2);		

		l=new JLabel("Enter the Scqurity Details");
		l.setFont(new Font("Serif",Font.BOLD,20));	
		l1=new JLabel(" Name:");
		l2=new JLabel(" Id:");
		l3=new JLabel("Addres:");
		l4=new JLabel("Phon No:");
		l5=new JLabel("Shift:");
		l6=new JLabel("Salary");
		l20=new JLabel("",new ImageIcon(ClassLoader.getSystemResource("image//sec.jpg")),10);			

		t1=new JTextField(20);
		t2=new JTextField(20);
		t3=new TextArea(15,15);
		t4=new JTextField(10);
		// t5=new JTextField(20);
		t6=new JTextField(10);
	JButton	 b3=new JButton("Back",new ImageIcon(ClassLoader.getSystemResource("image//back.png")));
		 b1=new JButton("Submit",new ImageIcon(ClassLoader.getSystemResource("image//insert.png")));
		b2=new JButton("Clear",new ImageIcon(ClassLoader.getSystemResource("image//clear.png")));

		setLayout(null);
		l.setBounds(60,20,300,20);            
		t1.setBounds(220,80,150,20);              
		l1.setBounds(60,80,200,20);            t2.setBounds(220,120,150,20);
		l2.setBounds(60,120,200,20);       	t3.setBounds(220,160,150,80);
		l3.setBounds(60,160,200,20);            t4.setBounds(220,270,150,20);
		l4.setBounds(60,270,200,20);           r1.setBounds(220,310,80,20); r2.setBounds(300,310,100,20); 
		l5.setBounds(60,310,200,20); 		t6.setBounds(220,350,150,20); 					
		l6.setBounds(60,350,200,20); 		b2.setBounds(220,390,110,30);

		b1.setBounds(60,390,110,30);		b3.setBounds(390,390,110,30); l20.setBounds(0,0,550,550);
		b3.addActionListener(this);





		//	p1=new JPanel();	

		//	p1.setLayout(new GridLayout(7,2));
		add(l1); add(t1); add(l2); add(t2);
		add(l3); add(t3); add(l4); add(t4);
		add(l5); add(r1);add(r2); add(l6); add(t6);
		add(b1); add(b2); add(l);	add(b3);add(l20);

		//	setLayout(new BorderLayout());
		//	add(l,BorderLayout.NORTH);
		//	add(p1,BorderLayout.CENTER);

		setTitle("Sequrity");
		setVisible(true);
		setSize(550,550);
		setLocation(100,100);

		r1.setSelected(true);
		b1.addActionListener(this);
		b2.addActionListener(this);
		//this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		Connection con;
		Statement s;
		ResultSet rs;
		int max=0;	
		try
		{
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			String path="D:\\ty file\\Projects\\Society Administration\\Database.mdb";
			String url="jdbc:ucanaccess://"+path;
			con=DriverManager.getConnection(url); 	
			s=con.createStatement();
			rs=s.executeQuery("select max(sid)from sequrity");
			if(rs.next())
			{
				max=rs.getInt(1);
			}
			con.close();
		}
		catch(Exception e){}
		max=max+1;
		t2.setText(Integer.toString(max));


	}

	public void actionPerformed(ActionEvent ae)
	{       
		
		
		String shift=null;
		String temp=ae.getActionCommand();
		  if(temp.equals("Submit"))
                {

		try
		{
		int sid=Integer.parseInt(t2.getText());
		String sname=t1.getText();
		String sadd=t3.getText();
	    int spno=Integer.parseInt(t4.getText());
		 
		if(r1.isSelected())	
			shift="Day";
		else
			shift="Night";
		int sal=Integer.parseInt(t6.getText());
		Connection con;
		PreparedStatement ps;
		ResultSet rs;
		int i=0;
		if(temp.equals("Submit"))
		{
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			String path="D:\\ty file\\Projects\\Society Administration\\Database.mdb";
			String url="jdbc:ucanaccess://"+path;
			con=DriverManager.getConnection(url); 	
			ps=con.prepareStatement("insert into sequrity values(?,?,?,?,?,?)");
			ps.setInt(1,sid);
			ps.setString(2,sname);			
			ps.setString(3,sadd);
			ps.setInt(4,spno);
			ps.setString(5,shift);
			ps.setInt(6,sal);
			i=ps.executeUpdate();
			if(i==1)
			{
				JOptionPane.showMessageDialog(null,"New Security Record is inserted","Security",JOptionPane.INFORMATION_MESSAGE);
			}		
			con.close();
		}		
				
		/*if(temp.equals("Clear"))
		{
			t1.setText("");
			t3.setText("");
			t4.setText("");
			t6.setText("");


		}*/
		}
		 catch(Exception e)

                {
                        String s=(e.toString() + e.getMessage());
                    //    System.out.println("BAD");

                        JOptionPane.showMessageDialog(null,"Make the Proper Entry ","Error",JOptionPane.ERROR_MESSAGE);
                }
		}
		if(temp.equals("Clear"))
                {
                        t1.setText("");
                        t3.setText("");
                        t4.setText("");
                        t6.setText("");


                }
		if(temp.equals("Back"))	
		{
			new Insert().setVisible(true);
			this.dispose();
		}



	}

	public static void main(String a[])
	{
		new Sequrity();
	}
}
