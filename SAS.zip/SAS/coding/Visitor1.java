import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class Visitor1 extends JFrame implements ActionListener 
{
	JRadioButton r1,r2;
	ButtonGroup bg;
	JLabel l1,l20;
	JButton b1;
	Visitor1()
	{
		b1=new JButton("Next",new ImageIcon(ClassLoader.getSystemResource("image//next.png")));
		l1=new JLabel("Select the Option");
		l1.setFont(new Font("Serif",Font.BOLD,20));

		l20=new JLabel("",new ImageIcon(ClassLoader.getSystemResource("image//com.jpg")),10);				
		
		bg=new ButtonGroup();


		r1=new JRadioButton("Serach");
		bg.add(r1);
                r2=new JRadioButton("Register");
                bg.add(r2);
		setLayout(null);
		l1.setBounds(60,20,200,20);
		r1.setBounds(60,60,100,20);
		r2.setBounds(60,100,100,20);
		b1.setBounds(60,140,110,20);
               	l20.setBounds(0,0,250,250);	
	//	setLayout(new GridLayout(3,1));
		add(l1); add(r1); add(r2); add(b1); add(l20);
	
		setVisible(true);
		setSize(250,250);
		setLocation(100,100);
		setTitle("Visitor");

		b1.addActionListener(this);
		r1.setSelected(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

		public void actionPerformed(ActionEvent ae)
		{
			String temp=ae.getActionCommand();
			if(temp.equals("Next"))
			{
				if(r1.isSelected()) 
					new Visitor3().setVisible(true);
				if(r2.isSelected())
			{
					new Visitor2().setVisible(true);
					this.dispose();
			}
			}
		}

	public static void main(String a[])
	{
		new Visitor1();
	}
}
