import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
public class Rule extends JFrame implements ActionListener
{
	JLabel l1,l2,l3,l4;
	JTextField t1;
	JTextArea a1; 
	JButton b1,b2,b3;
	JPanel p1,p2;

	Rule()
	{
		l1=new JLabel("Define the Rule:");
		l1.setFont(new Font("Serif",Font.BOLD,20));
		l2=new JLabel("Rule No:");
		l3=new JLabel("Define Rule:");
		 b3=new JButton("Back",new ImageIcon(ClassLoader.getSystemResource("image//back.png")));
		t1=new JTextField(100);
		a1=new JTextArea(10,10);
		b1=new JButton("Submit",new ImageIcon(ClassLoader.getSystemResource("image//insert.png")));
		b2=new JButton("Clear",new ImageIcon(ClassLoader.getSystemResource("image//clear.png")));
 		l4=new JLabel("",new ImageIcon(ClassLoader.getSystemResource("image//rules.gif")),10);	
		setLayout(null);

		l1.setBounds(60,20,300,20);             t1.setBounds(220,80,150,20);
		l2.setBounds(60,80,200,20);             a1.setBounds(220,120,150,100);
		l3.setBounds(60,120,200,20);         	 b2.setBounds(220,280,110,30);
		b1.setBounds(60,280,110,30);		b3.setBounds(360,280,110,30);
		l4.setBounds(0,0,500,500);



		//	p1=new JPanel();
		//	p2=new JPanel();

		//	p1.setLayout(new GridLayout(2,2));
		add(l1);
		add(l2); add(t1);
		add(l3); add(a1);

		//	p2.setLayout(new GridLayout(1,2));
		add(b1); add(b2); add(b3);add(l4);

		/*	setLayout(new BorderLayout());
			add(p1,BorderLayout.CENTER);
			add(p2,BorderLayout.SOUTH);
			add(l1,BorderLayout.NORTH);*/

		setTitle("Rule");
		setVisible(true);
		setLocation(100,100);
		setSize(500,500);
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
	//	this.setDefaultCloseOperation(EXIT_ON_CLOSE);

		Connection con;
		Statement s;
		ResultSet rs;
		int max=0;	
		try
		{
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			String path="D:\\ty file\\Projects\\Society Administration\\Database.mdb";
			String url="jdbc:ucanaccess://"+path;
			con=DriverManager.getConnection(url); 	
			s=con.createStatement();
			rs=s.executeQuery("select max(rno)from rule");
			if(rs.next())
			{
				max=rs.getInt(1);
			}
			con.close();
		}
		catch(Exception e){}
		max=max+1;
		t1.setText(Integer.toString(max));


	}

	public void actionPerformed(ActionEvent ae)
	{
		Connection con;
		PreparedStatement ps;
		ResultSet rs;

		String temp=ae.getActionCommand();
		String rule=a1.getText();
		int    no= Integer.parseInt(t1.getText());
		int i=0;


		if(temp.equals("Submit"))
		{

			try
			{			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			String path="D:\\ty file\\Projects\\Society Administration\\Database.mdb";
			String url="jdbc:ucanaccess://"+path;
			con=DriverManager.getConnection(url); 	
				ps=con.prepareStatement("insert into rule values(?,?)");
				ps.setInt(1,no);
				ps.setString(2,rule);

				i=ps.executeUpdate();
				if(i==1)
				{
					JOptionPane.showMessageDialog(null,"New Rule is inserted","Rule",JOptionPane.INFORMATION_MESSAGE);
				}			




				con.close();	
			}
			catch (Exception e) 
			{
				String s=(e.toString() + e.getMessage());	
			JOptionPane.showMessageDialog(null,s,"Error",JOptionPane.ERROR_MESSAGE);	
			}		
		}
			if(temp.equals("Clear"))
			{

				a1.setText("");
			}
			if(temp.equals("Back"))	
		{
			new Admin().setVisible(true);
			this.dispose();
		}



		
	}

	public static void main(String a[])
	{
		{
			new Rule();
		}

	}
}


