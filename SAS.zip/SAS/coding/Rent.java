import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
public class Rent extends JFrame implements ActionListener
{
	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l20;
	JTextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13;
	//JRadioButton r1,r2,r3;
	JButton b1,b2,b3;
	DateButton t_date;
	//ButtonGroup bg;	
	Rent()
	{
		/*bg=new ButtonGroup();
		r1=new JRadioButton("1BHK");
		bg.add(r1);
		r2=new JRadioButton("2BHK");
		bg.add(r2);
		r3=new JRadioButton("3BHK");
		bg.add(r3);*/
		l1=new JLabel("Enter The Renter Details");
		l1.setFont(new Font("Serif",Font.BOLD,20));
		l2=new JLabel("Renter Id");
		l3=new JLabel("Renter Name");
		l4=new JLabel("Renter Email Id");
		l5=new JLabel("Renter Mobile No");
		l6=new JLabel("Renter Landline No");
		l7=new JLabel("Total Members in Family");
		l8=new JLabel("On Renter From Date");
		l9=new JLabel("Renter Duration(In Months)");
		l10=new JLabel("Owner Id");
		l11=new JLabel("Flat No");
		t_date = new DateButton();
		//l12=new JLabel("Parking No");
		l20=new JLabel("",new ImageIcon(ClassLoader.getSystemResource("image//com.jpg")),10);				
		b1=new JButton("Submit",new ImageIcon(ClassLoader.getSystemResource("image//insert.png")));
		b2=new JButton("Clear",new ImageIcon(ClassLoader.getSystemResource("image//clear.png")));
		b3=new JButton("Back",new ImageIcon(ClassLoader.getSystemResource("image//back.png")));
		t1=new JTextField("");
                t2=new JTextField("");
                t3=new JTextField("");
                t4=new JTextField("");
                t5=new JTextField("");
                t6=new JTextField("");
                t7=new JTextField("");
                t8=new JTextField("");
                t9=new JTextField("");
                t10=new JTextField("");
                t11=new JTextField("");
                //t12=new JTextField("");

		setLayout(null);
		l1.setBounds(60,20,400,20);
		l2.setBounds(60,60,200,20);	t1.setBounds(250,60,150,20);
		l3.setBounds(60,100,200,20);	t2.setBounds(250,100,150,20);
		l4.setBounds(60,140,200,20);	t3.setBounds(250,140,150,20);
		l5.setBounds(60,180,200,20);	t4.setBounds(250,180,150,20);
		l6.setBounds(60,220,200,20);	t5.setBounds(250,220,150,20);
		l7.setBounds(60,260,200,20);	t6.setBounds(250,260,150,20);
		l8.setBounds(60,300,200,20);	t_date.setBounds(250,300,150,20);
		l9.setBounds(60,340,200,20);	t8.setBounds(250,340,150,20);
		l20.setBounds(00,0,600,600);
		//r1.setBounds(60,360,80,20); r2.setBounds(140,360,80,20); r3.setBounds(250,360,80,20);
		l10.setBounds(60,380,200,20);	t9.setBounds(250,380,150,20);
		l11.setBounds(60,420,200,20);	t10.setBounds(250,420,150,20);
		//l12.setBounds(60,480,200,20);	t10.setBounds(250,480,150,20);
		b1.setBounds(60,520,110,30);	b2.setBounds(250,520,110,30); b3.setBounds(400,520,110,30);

		add(l1); add(l2);add(l3);add(l4);add(l5);add(l6);add(l7);add(l8);add(l9);add(l10);add(l11);//add(l12);
		add(t1);add(t2);add(t3);add(t4);add(t5);add(t6);add(t_date);add(t8);add(t9);add(t10);add(b3);
		add(b1); add(b2);add(l20);// add(r2);add(r3);
	setVisible(true);
	setLocation(100,100);
	setSize(600,600);
	setTitle("Rnter");
//	r1.setSelected(true);
	b1.addActionListener(this);
	b2.addActionListener(this);
	b3.addActionListener(this);
	Connection con;
		Statement s;
		ResultSet rs;
		int max=0;	
		try
		{
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			String path="D:\\ty file\\Projects\\Society Administration\\Database.mdb";
			String url="jdbc:ucanaccess://"+path;
			con=DriverManager.getConnection(url); 	
			s=con.createStatement();
			rs=s.executeQuery("select max(rno)from rent");
			if(rs.next())
			{
				max=rs.getInt(1);
			}
			con.close();
		}
		catch(Exception e){}
		max=max+1;
		t1.setText(Integer.toString(max));


	}
	public void actionPerformed(ActionEvent ae)
	{ 
		String temp=ae.getActionCommand();
		
		if(temp.equals("Submit"))
		{
		try
		{	Connection con;
			PreparedStatement ps;
			ResultSet rs;
			//String temp1=null;
			int i=0;
			int rno=Integer.parseInt(t1.getText());
			String rent=t2.getText();
			String email=t3.getText();
		    int mno=Integer.parseInt(t4.getText());
			int lno=Integer.parseInt(t5.getText());
			int mem=Integer.parseInt(t6.getText());
		String rd=t_date.getText();
			 
			int dur=Integer.parseInt(t8.getText());
			int oid=Integer.parseInt(t9.getText());
			int fno=Integer.parseInt(t10.getText());
	
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			String path="D:\\ty file\\Projects\\Society Administration\\Database.mdb";
			String url="jdbc:ucanaccess://"+path;
			con=DriverManager.getConnection(url); 	
				
			ps=con.prepareStatement("insert into  rent values(?,?,?,?,?,?,?,?,?,?)");
		System.out.println(rd);

			ps.setInt(1,rno);
			ps.setString(2,rent);
			ps.setString(3,email);
			ps.setInt(4,mno);
			ps.setInt(5,lno);
			ps.setInt(6,mem);
			ps.setString(7,rd);
			 ps.setInt(8,dur);
			 ps.setInt(9,oid);
			 ps.setInt(10,fno);
			i=ps.executeUpdate();
			 

			/*if(r1.isSelected())
				temp1="1BHK";
			if(r2.isSelected())
                                temp1="2BHK";
			if(r3.isSelected())
                                temp1="3BHK";


			 int fid=Integer.parseInt(t7.getText());
			 String wing=t8.getText();
			 int floor=Integer.parseInt(t9.getText());
			 int park=Integer.parseInt(t10.getText());

			  ps=con.prepareStatement("insert into  flat values(?,?,?,?,?,?)");
			 ps.setInt(1,fid);
			 ps.setString(2,wing);
			 ps.setString(4,temp1);
        		 ps.setInt(3,floor);
			 ps.setInt(5,park);
			 ps.setInt(6,oid);
			 int j=ps.executeUpdate();*/


			if(i==1)
			{
				JOptionPane.showMessageDialog(null,"New Rent Record is inserted","Rent",JOptionPane.INFORMATION_MESSAGE);
			}		
			con.close();
			
		}  
		catch(Exception e)
			{
				String s=(e.toString() + e.getMessage());	
			JOptionPane.showMessageDialog(null,s,"Error",JOptionPane.ERROR_MESSAGE);	
			}
		}
		if(temp.equals("Clear"))
		{
		t2.setText(""); t3.setText(""); t4.setText(""); t5.setText(""); t6.setText(""); t7.setText("");	
		 t8.setText(""); t9.setText(""); t10.setText("");
		}
		if(temp.equals("Back"))	
		{
			new Insert().setVisible(true);
			this.dispose();
		}
	}
	
	public  static void main(String a[])
	{
		new Rent();
	}
}

