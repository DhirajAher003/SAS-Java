import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class Other extends JFrame implements ActionListener
{
	JLabel l1,l2,l20;
	JTextField t1;
	JTextArea a1; 
	JButton b1;
	JRadioButton r1,r2;
	ButtonGroup bg;
	//Panel p1,p2;
	
	Other()
	{	bg=new ButtonGroup();	
		l1=new JLabel("Wellcome Member");
		l1.setFont(new Font("Serif",Font.BOLD,20));
		l2=new JLabel("Select the option");
		r1=new JRadioButton("Search");
		bg.add(r1);
		r2=new JRadioButton("Complen box");
		bg.add(r2);
		b1=new JButton("Next",new ImageIcon(ClassLoader.getSystemResource("image//next.png")));
		l20=new JLabel("",new ImageIcon(ClassLoader.getSystemResource("image//com.jpg")),10);						
		setLayout(null);
		
		 l1.setBounds(60,20,300,20);        //     t1.setBounds(220,80,150,20);
                 l2.setBounds(60,60,200,20);          //   a1.setBounds(220,120,150,100);
                 r1.setBounds(60,100,200,20);         	// b2.setBounds(220,240,80,20);
                 r2.setBounds(60,140,200,20);
		 b1.setBounds(60,180,110,30);
		l20.setBounds(00,0,450,450);	

		
	//	p1=new JPanel();
	//	p2=new JPanel();

	//	p1.setLayout(new GridLayout(2,2));
		add(l1);
		add(l2); add(r1);
		add(r2); add(b1);
		add(l20);	
	//	p2.setLayout(new GridLayout(1,2));
		//add(b1); add(b2);
		
	/*	setLayout(new BorderLayout());
		add(p1,BorderLayout.CENTER);
		add(p2,BorderLayout.SOUTH);
		add(l1,BorderLayout.NORTH);*/
		
		setTitle("Member");
		setVisible(true);
		setLocation(100,100);
		setSize(450,350);
		r1.setSelected(true);
		b1.addActionListener(this);
		 
		
	}
	public void actionPerformed(ActionEvent ae)
	{	
		
		
		String temp=ae.getActionCommand();
		if(temp.equals("Next"))
		{
		if (r1.isSelected())
			new search2();
			this.dispose();
				
		 if(r2.isSelected())
			new Complainbox();
			this.dispose();
		/*else if(r3.isSelected())
			temp1=("sequrity");*/
		}
	}
	public static void main(String a[])
	{
		new Other();
	}

}
