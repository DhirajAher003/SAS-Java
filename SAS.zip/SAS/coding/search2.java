import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.sql.*;
import java.io.*;
import javax.swing.table.*;
public class search2 implements ActionListener
{
	JPanel p1,p2,p3,p4,p5;
	JFrame f;
	JLabel l1,l2,l3,l4;
	JButton b1,b2,b3,b4,b5;
	JTextField t1,t2,t3,t4;
	//JButton b;

	search2()
	{
		p1=new JPanel();
		p1.setLayout(new GridLayout(4,3));
		l1=new JLabel("Enter Security Name");
		t1=new JTextField(10);
		p1.add(l1);p1.add(t1);
		b1=new JButton("Search1");
		p1.add(b1);
		b5=new JButton("Back");
		p2=new JPanel();
		p2.setLayout(new FlowLayout());
		p2.add(b5);
                l2=new JLabel("Enter Owner Name");
                t2=new JTextField(10);
                p1.add(l2);p1.add(t2);
                b2=new JButton("Search2");
                p1.add(b2);
		
	//	p3=new JPanel();
	//	p3.setLayout(new FlowLayout());
                l3=new JLabel("Enter Rent Name");
                t3=new JTextField(10);
                p1.add(l3);p1.add(t3);
                b3=new JButton("Search3");
                p1.add(b3);
	
		p5=new JPanel();
	//	p4.setLayout(new FlowLayout());
                l4=new JLabel("Enter Manten Date");
                t4=new JTextField(10);
                p1.add(l4);p1.add(t4);
                b4=new JButton("Search4");
                p1.add(b4);


		b1.addActionListener(this);
		 b2.addActionListener(this);
		 b3.addActionListener(this);
 		b4.addActionListener(this);
		b5.addActionListener(this);
		
	//	p1.setBounds(60,60,250,20);
	//	add(p1);
		f=new JFrame();
		f.setLayout(new BorderLayout());
		f.add(p1,BorderLayout.CENTER);
		f.add(p2,BorderLayout.SOUTH);
		f.setSize(500,400);
		f.setVisible(true);
		f.setLocation(100,100);
	//	f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public void actionPerformed(ActionEvent ae)
	{
		try
		{	String temp=ae.getActionCommand();
		Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		String path="D:\\ty file\\Projects\\Society Administration\\Database.mdb";
		String url="jdbc:ucanaccess://"+path;
//		con=DriverManager.getConnection(url); 	
			if(temp.equals("Search1"))
			{
			String id = t1.getText();
			//f.setVisible(false);
			new s(id).setVisible(true);
			}
			 if(temp.equals("Search2"))
                        {
                        String id = t2.getText();
                        //f.setVisible(false);
                        new s2(id).setVisible(true);
			}
                        if(temp.equals("Search3"))
                        {
                        String id = t3.getText();
                        //f.setVisible(false);
                        new s3(id).setVisible(true);
                        }
                        if(temp.equals("Search4"))
                        {
                        String id = t4.getText();
                        //f.setVisible(false);
                        new s4(id).setVisible(true);
                        }
			if(temp.equals("Back"))	
		{
			new Other();
			f.dispose();
		}

		}
		catch(Exception e){}
	}

	public static void main(String a[])
	{
		new search2();
	}

}
