import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
public class Visitor2 extends JFrame implements ActionListener
{
	JLabel l1,l2,l3,l4,l5,l6,l7,l9;
	JTextField t1,t2,t3,t4,t5,t6;
	JButton b1,b2,b3;
	DateButton t_date;
	Visitor2()
	{
                l6=new JLabel("Enter the Visitor Dtails");
		l6.setFont(new Font("Safari",Font.BOLD,20));
		l1=new JLabel(" Visitor Id:");
                l2=new JLabel(" In Time:");
                l3=new JLabel("Date");
                l4=new JLabel("To Whom Visiting:");
		l7=new JLabel("Flat no");
                l5=new JLabel("Name of Visitor:");
                	
		t1=new JTextField(20);
		t_date = new DateButton();
		t2=new JTextField(20);
                t3=new JTextField(10);
                t4=new JTextField(20);
                t5=new JTextField(10);
		t6=new JTextField(10);
		 l9=new JLabel("User Name",new ImageIcon(ClassLoader.getSystemResource("image//reg.jpg")),10);	
		b1=new JButton("Submit" ,new ImageIcon(ClassLoader.getSystemResource("image//insert.png")));
		b2=new JButton("Clear",new ImageIcon(ClassLoader.getSystemResource("image//clear.png")));
		b3=new JButton("Back",new ImageIcon(ClassLoader.getSystemResource("image//back.png")));				


		setLayout(null);
		l6.setBounds(60,20,300,20);            
		l1.setBounds(60,60,200,20);	t1.setBounds(220,60,150,20);              
		l2.setBounds(60,100,200,20);    t2.setBounds(220,100,150,20);
		l3.setBounds(60,140,200,20);    t_date.setBounds(220,140,150,20);
		l4.setBounds(60,180,200,20);    t4.setBounds(220,180,150,20);
		l7.setBounds(60,220,200,20);    t6.setBounds(220,220,150,20);
		l5.setBounds(60,260,200,20);	t5.setBounds(220,260,150,20);
		b1.setBounds(60,300,110,30);	 b2.setBounds(200,300,110,30); b3.setBounds(330,300,110,30);
		l9.setBounds(0,0,500,500);



	


		//	p1=new JPanel();	

		//	p1.setLayout(new GridLayout(7,2));
		add(l1); add(t1); add(l2); add(t_date);
		add(l3); add(t2); add(l4); add(t4);
		add(l5); add(t5); add(l6); add(l7);
		add(b1); add(b2); add(t6); add(b3);add(l9);

		//	setLayout(new BorderLayout());
		//	add(l,BorderLayout.NORTH);
		//	add(p1,BorderLayout.CENTER);

		setTitle("Sequrity");
		setVisible(true);
		setSize(500,500);
		setLocation(100,100);

		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		Connection con;
		Statement s;
		ResultSet rs;
		int max=0;	
		try
		{			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		String path="D:\\ty file\\Projects\\Society Administration\\Database.mdb";
		String url="jdbc:ucanaccess://"+path;
		con=DriverManager.getConnection(url); 	
			s=con.createStatement();
			rs=s.executeQuery("select max(vno)from  visitor");
			if(rs.next())
			{
				max=rs.getInt(1);
			}
			con.close();
		}
		catch(Exception e){}
		max=max+1;
		t1.setText(Integer.toString(max));



	}
	public void actionPerformed(ActionEvent ae)
	{ 
		String temp=ae.getActionCommand();
		if(temp.equals("Submit"))
		{
			try
			{	Connection con;
				PreparedStatement ps;
				ResultSet rs;
				String temp1=null;
				int i=0;
				int vid=Integer.parseInt(t1.getText());
				String tim=t2.getText();
				String dat=t_date.getText();
				String onm=t4.getText();
				int fno=Integer.parseInt(t6.getText());
				String vname=t5.getText();
				Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
				String path="D:\\ty file\\Projects\\Society Administration\\Database.mdb";
				String url="jdbc:ucanaccess://"+path;
				con=DriverManager.getConnection(url); 				
				ps=con.prepareStatement("insert into  visitor values(?,?,?,?,?,?)");

				ps.setInt(1,vid);	
				ps.setString(2,tim);
				ps.setString(3,dat);
				ps.setString(4,onm);
				ps.setInt(5,fno);
				ps.setString(6,vname);
				i=ps.executeUpdate();
				if(i==1)
			{
				JOptionPane.showMessageDialog(null,"New Visitor Record is inserted","Visitor",JOptionPane.INFORMATION_MESSAGE);
			}		
			con.close();
			
		}  
		catch(Exception e)
			{
				String s=(e.toString() + e.getMessage());	
			JOptionPane.showMessageDialog(null,s,"Erorr",JOptionPane.ERROR_MESSAGE);	
			}
		}
		if(temp.equals("Clear"))
		{
		t2.setText(""); t3.setText(""); t4.setText(""); t5.setText(""); t6.setText(""); 
		}
	if(temp.equals("Back"))	
		{
			new Visitor1().setVisible(true);
			this.dispose();
		}
	}
	public static void main(String a[])
	{
		new Visitor2();
	}
}
