import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
public class Chairman extends JFrame implements ActionListener
{
	JLabel l1,l2,l3,l4,l5,l20;
	JTextField t1,t2,t3,t4;
	JButton b1,b2,b3;
	DateButton t_date,t_date1;
	//JPanel p1,p2;
	Chairman()
	{
		l1=new JLabel("Enter The Chairman Detail");
		l1.setFont(new Font("Serif",Font.BOLD,20));		
		l2=new JLabel("Chairman Id");
		l3=new JLabel("Owner Id");
		l4=new JLabel("From The Date");
		l5=new JLabel("To The Date");
		l20=new JLabel("",new ImageIcon(ClassLoader.getSystemResource("image//com.jpg")),10);		
		t1=new JTextField(10);
		t2=new JTextField(10);
		t3=new JTextField(10);
		t4=new JTextField(10);
		b3=new JButton("Back",new ImageIcon(ClassLoader.getSystemResource("image//back.png")));
		b1=new JButton("Submit",new ImageIcon(ClassLoader.getSystemResource("image//insert.png")));
		b2=new JButton("Clear",new ImageIcon(ClassLoader.getSystemResource("image//clear.png")));
		t_date = new DateButton();
		t_date1 = new DateButton();
		setLayout(null);
		//p1=new JPanel();
		//p2=new JPanel();

		l1.setBounds(60,20,300,20);		 t1.setBounds(220,80,150,20);
		l2.setBounds(60,80,200,20);		 t2.setBounds(220,120,150,20);
		l3.setBounds(60,120,200,20);		 t_date.setBounds(220,160,150,20);
		l4.setBounds(60,160,200,20);		 t_date1.setBounds(220,200,150,20);
		l5.setBounds(60,200,200,20);		 b2.setBounds(220,240,110,30);
		b1.setBounds(60,240,110,30);		b3.setBounds(360,240,110,30);
		l20.setBounds(0,0,500,400);

		//p1.setLayout(new GridLayout(4,2));	
		add(l1);
		add(l2); add(t1);
		add(l3); add(t2);
		add(l4); add(t_date);
		add(l5); add(t_date1);

		//p2.setLayout(new GridLayout(1,2));
		add(b1); add(b2); add(b3);add(l20);

		/*setLayout(new BorderLayout());
		  add(p1,BorderLayout.CENTER);
		  add(p2,BorderLayout.SOUTH);
		  add(l1,BorderLayout.NORTH);*/

		setTitle("Chairman");
		setVisible(true);
		setLocation(100,100);
		setSize(500,350);
	//	this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		Connection con;
		Statement s;
		ResultSet rs;	
		int max=0;
		try
		{
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			String path="D:\\ty file\\Projects\\Society Administration\\Database.mdb";
			String url="jdbc:ucanaccess://"+path;
			con=DriverManager.getConnection(url); 	
			s=con.createStatement();
			rs=s.executeQuery("select max(chid)from chairman");
			if(rs.next())
			{
				max=rs.getInt(1);
			}
			con.close();
		}		
		catch(Exception e){}
		max=max+1;
		t1.setText(Integer.toString(max));

	}
	public void actionPerformed(ActionEvent ae)
	{
		String temp=ae.getActionCommand();
		if(temp.equals("Submit"))
		{
		System.out.println("qwe");
		int hid=Integer.parseInt(t1.getText());
		int wid=Integer.parseInt(t2.getText());
		String fd=t_date.getText();
		String td=t_date1.getText();
		int i=0;
		try
		{	Connection con;
			PreparedStatement ps;
			ResultSet rs;
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			String path="D:\\ty file\\Projects\\Society Administration\\Database.mdb";
			String url="jdbc:ucanaccess://"+path;
			con=DriverManager.getConnection(url); 				 System.out.println("qwe");
			ps=con.prepareStatement("insert into  chairman values(?,?,?,?)");
			ps.setInt(1,hid);
			ps.setInt(2,wid);
			ps.setString(3,fd);
			ps.setString(4,td);
			 System.out.println("qwe");
		 i=ps.executeUpdate();
		
		if(i==1)
			{
				JOptionPane.showMessageDialog(null,"New Rent Record is inserted","Rent",JOptionPane.INFORMATION_MESSAGE);
			}		
			con.close();
			

			
		}
		catch(Exception e){JOptionPane.showMessageDialog (null,"Make Proper Entry","Error",JOptionPane.ERROR_MESSAGE);}
		
		}
	if(temp.equals("Back"))	
		{
			new Insert().setVisible(true);
			this.dispose();
		}
	if(temp.equals("Clear"))
		{
			t2.setText("");
			t3.setText("");
			t4.setText("");
		}
	}
	public static void main(String a[])
	{
		new Chairman();
	}



}
