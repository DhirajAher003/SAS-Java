import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class Admin extends JFrame implements ActionListener
{
	JRadioButton r1,r2,r3,r4;
	JLabel l1,l2;
	ButtonGroup bg;
	JButton b1;
	Admin()
	{
		b1=new JButton("Next",new ImageIcon(ClassLoader.getSystemResource("image//next.png")));
		l1=new JLabel("Select The Option");
		l1.setFont(new Font("Serif",Font.BOLD,20));
		bg=new ButtonGroup();
		l2=new JLabel("",new ImageIcon(ClassLoader.getSystemResource("image//com.jpg")),10);		
		r1=new JRadioButton("Insert");
		bg.add(r1);
                r2=new JRadioButton("Update");
                bg.add(r2);
                r3=new JRadioButton("Search");
                bg.add(r3);
		r4=new JRadioButton("Total Report");
                bg.add(r4);
		setLayout(null);
	//	setLayout(new GridLayout(5,1));
	//	add(r1); add(r2); add(r3); add(r4); add(b1);
		l1.setBounds(60,20,250,20);
		r1.setBounds(60,60,150,20);
		r2.setBounds(60,100,150,20);
		r3.setBounds(60,140,150,20);
		r4.setBounds(60,180,150,20);
		b1.setBounds(60,220,110,20);
		l2.setBounds(0,0,500,300);
		add(l1);add(r1); add(r2); add(r3);add(r4);  add(b1);add(l2);
	

		setVisible(true);
		setSize(500,300);
		setLocation(100,100);
		setTitle("Admin");
		r1.setSelected(true);
		b1.addActionListener(this);
		
	}
	public void actionPerformed(ActionEvent ae)
	{
		String temp=ae.getActionCommand();
		if (r1.isSelected())
			new Insert().setVisible(true);
			this.dispose();
		 if(r2.isSelected())
			new Update().setVisible(true);
			this.dispose();
		 if(r3.isSelected())
			new search();
			this.dispose();

		if(r4.isSelected())
			new display().setVisible(true);
			this.dispose();

	}	
	public static void main(String a[])
	{
		new Admin();
	}
}
