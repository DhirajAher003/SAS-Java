import java.awt.*;
import javax.swing.*;
import java.sql.*;
import javax.swing.table.*;
import com.sun.rowset.*;
import java.io.*;
import javax.sql.rowset.*;
import javax.swing.JScrollPane.*; 
public class display extends JFrame 
  {

	Connection con;
	final static String MYPANEL0 = "Owner";
    final static String MYPANEL1 = "Flat";
    final static String MYPANEL2 = "Owner";
    final static String MYPANEL3 = "Rent";
    final static String MYPANEL4 = "Visitor";
    final static String MYPANEL5 = "Maintenance";
    final static String MYPANEL6 = "Complainbox";
    final static String MYPANEL7 = "Security";
       final static String MYPANEL11= "Total Record";
	

          Font dataFont = new Font("courier new",Font.BOLD,14);
             
           Container contentPane = getContentPane();
                  JTabbedPane tabbedPane = new JTabbedPane();
                
              int tempcnt,tempcnt1;
               String tempname = "";
               Object[] data = new Object[20];
                 DefaultTableModel defaulttablemodel1 = new DefaultTableModel();
                 JTable jtable1 = new JTable(defaulttablemodel1);
                 DefaultTableModel defaulttablemodel0 = new DefaultTableModel();
                 JTable jtable0 = new JTable(defaulttablemodel0);
               
                DefaultTableModel defaulttablemodel2 = new DefaultTableModel();
                 JTable jtable2 = new JTable(defaulttablemodel2);
                 
                 DefaultTableModel defaulttablemodel3 = new DefaultTableModel();
                 JTable jtable3 = new JTable(defaulttablemodel3);
 		
                  DefaultTableModel defaulttablemodel4 = new DefaultTableModel();
                 JTable jtable4 = new JTable(defaulttablemodel4);
	
         	 DefaultTableModel defaulttablemodel5 = new DefaultTableModel();
                 JTable jtable5 = new JTable(defaulttablemodel5);
		
                  DefaultTableModel defaulttablemodel6 = new DefaultTableModel();
                 JTable jtable6 = new JTable(defaulttablemodel6);
		 
                 DefaultTableModel defaulttablemodel7 = new DefaultTableModel();
                 JTable jtable7 = new JTable(defaulttablemodel7);
		
    
              TableColumn column,column1;            
              
          
       display()

             {         //************************first standard**********************
                     
                    contentPane.add(tabbedPane, BorderLayout.CENTER);
			
                     setSize(1025,700);
                  //setsizable(false);
                       setVisible(true);

               setTitle(" \" OVERALL SOCIETY INFOMATION  \"");


                     JPanel p1 = new JPanel();
                  p1.setLayout(new GridLayout()); 
          p1.setBackground(new Color(180,159,120));        

             p1.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(),"flat"));
                            try
                         {
                        
                    			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
                    			String path="D:\\ty file\\Projects\\Society Administration\\Database.mdb";
                    			String url="jdbc:ucanaccess://"+path;
                    			con=DriverManager.getConnection(url); 	
                    			Statement statement = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
                
  // String query ="SELECT fno as Flat_No,wing as Wing,ftype as Flat_Type,parkno as Parking_no,flat.oid as Owner_Id,oname as Owner_Name FROM flat,owner where owner.oid=flat.oid";
    String query="SELECT * FROM flat";                                  
                                       ResultSet rs = statement.executeQuery(query);

                                        ResultSetMetaData rmeta = rs.getMetaData();
 
                                        int numColumns=rmeta.getColumnCount();
                                         
                                   for(int j=1;j<=numColumns;++j)
                                       {
                                               if(j<=numColumns)
                                               {
                                                        defaulttablemodel1.addColumn(rmeta.getColumnName(j));
                                                }
                                        }
                                        while(rs.next())
                                        {
                                                for(int j=1;j<=numColumns;++j)
                                               {
                                                        if(j<=numColumns)
                                                        {
                                                              tempname = rs.getString(j);
                                                                tempcnt=j-1;
                                                               data[tempcnt] = tempname;
                                                      }
                                                }
                                               defaulttablemodel1.addRow(data);
                                        }
                 }
                        
                       catch(Exception ex)
                          {
                            System.out.println(""+ex);
                          }
                       
           int v = ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
           int h = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;
                 p1.add(new JScrollPane(jtable1,v,h));
                 tabbedPane.addTab(MYPANEL1, p1);
                             
//******************** 2nd standard **************************
              
                   JPanel p2 = new JPanel();
                   p2.setLayout(new GridLayout());
 p2.setBackground(new Color(180,159,120));
 
p2.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(),"Owner"));
                            try
                         {
                    			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
                    			String path="D:\\ty file\\Projects\\Society Administration\\Database.mdb";
                    			String url="jdbc:ucanaccess://"+path;
                    			con=DriverManager.getConnection(url); 	
            Statement statement = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);


    String query ="SELECT oid as Owner_id ,oname as Owner_Name,oeid as Email,mno as Mobile,llno as Landline,nfamily as No_Of_Members  FROM owner";
			
                                       ResultSet rs = statement.executeQuery(query);

                                        ResultSetMetaData rmeta = rs.getMetaData();

                                        int numColumns=rmeta.getColumnCount();

                                   for(int i=1;i<=numColumns;++i)
                                       {
                                               if(i<=numColumns)
                                               {
                                                        defaulttablemodel2.addColumn(rmeta.getColumnName(i));
                                                }
                                        }
                                        while(rs.next())
                                        {
                                                for(int i=1;i<=numColumns;++i)
                                               {
                                                        if(i<=numColumns)
                                                        {
                                                              tempname = rs.getString(i);
                                                                tempcnt=i-1;
                                                               data[tempcnt] = tempname;
                                                      }
                                                }
                                               defaulttablemodel2.addRow(data);
                                        }
                 }

                       catch(Exception ex2)
                          {
                            System.out.println(""+ex2);
                          }
                 p2.add(new JScrollPane(jtable2,v,h));
                 tabbedPane.addTab(MYPANEL2, p2);

//*********************** RENT ********************          
          JPanel p3 = new JPanel();
                   p3.setLayout(new GridLayout());
                    p3.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(),"RENT"));
                            try
                         {
                    			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
                    			String path="D:\\ty file\\Projects\\Society Administration\\Database.mdb";
                    			String url="jdbc:ucanaccess://"+path;
                    			con=DriverManager.getConnection(url); 	
			Statement statement = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);

    String query ="SELECT *  FROM rent";

                                       ResultSet rs = statement.executeQuery(query);

                                        ResultSetMetaData rmeta = rs.getMetaData();

                                        int numColumns=rmeta.getColumnCount();

                                   for(int k=1;k<=numColumns;++k)
                                       {
                                               if(k<=numColumns)
                                               {
                                                        defaulttablemodel3.addColumn(rmeta.getColumnName(k));
                                                }
                                        }
                                        while(rs.next())
                                        {
                                                for(int k=1;k<=numColumns;++k)
                                               {
                                                        if(k<=numColumns)
                                                        {
                                                              tempname = rs.getString(k);
                                                                tempcnt=k-1;
                                                               data[tempcnt] = tempname;
                                                      }
                                                }
                                               defaulttablemodel3.addRow(data);
                                        }
                 }

                       catch(Exception ex3)
                          {
                            System.out.println(""+ex3);
                          }
                 p3.add(new JScrollPane(jtable3,v,h));
                 tabbedPane.addTab(MYPANEL3, p3);

//************************* 4th standard *************************
 JPanel p4 = new JPanel();
                   p4.setLayout(new GridLayout());
                    p4.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(),"Visitor"));
                            try
                         {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			String path="D:\\ty file\\Projects\\Society Administration\\Database.mdb";
			String url="jdbc:ucanaccess://"+path;
			con=DriverManager.getConnection(url); 	
			
            Statement statement = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);

    String query ="SELECT vno as Id,vname as Name,vin as Time,vdate as Date,oname as Member,fno as FlatNo FROM visitor  ORDER BY vdate";

                                       ResultSet rs = statement.executeQuery(query);

                                        ResultSetMetaData rmeta = rs.getMetaData();

                                        int numColumns=rmeta.getColumnCount();

                                   for(int l=1;l<=numColumns;++l)
                                       {
                                               if(l<=numColumns)
                                               {
                                                        defaulttablemodel4.addColumn(rmeta.getColumnName(l));
                                                }
                                        }
                                        while(rs.next())
                                        {
                                                for(int l=1;l<=numColumns;++l)
                                               {
                                                        if(l<=numColumns)
                                                        {
                                                              tempname = rs.getString(l);
                                                                tempcnt=l-1;
                                                               data[tempcnt] = tempname;
                                                      }
                                                }
                                               defaulttablemodel4.addRow(data);
                                        }
                 }

                       catch(Exception ex3)
                          {
                            System.out.println(""+ex3);
                          }
                 p4.add(new JScrollPane(jtable4,v,h));
                 tabbedPane.addTab(MYPANEL4, p4);

 //**************************** 5th standard *******************
  JPanel p5 = new JPanel();
                   p5.setLayout(new GridLayout());
                    p5.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(),"Maintainance"));
                            try
                         {
                    			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
                    			String path="D:\\ty file\\Projects\\Society Administration\\Database.mdb";
                    			String url="jdbc:ucanaccess://"+path;
                    			con=DriverManager.getConnection(url); 				
              
            Statement statement = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);

    String query ="SELECT * FROM IMaintenance ORDER BY idate";

                                       ResultSet rs = statement.executeQuery(query);

                                        ResultSetMetaData rmeta = rs.getMetaData();

                                        int numColumns=rmeta.getColumnCount();

                                   for(int m=1;m<=numColumns;++m)
                                       {
                                               if(m<=numColumns)
                                               {
                                                        defaulttablemodel5.addColumn(rmeta.getColumnName(m));
                                                }
                                        }
                                        while(rs.next())
                                        {
                                                for(int m=1;m<=numColumns;++m)
                                               {
                                                        if(m<=numColumns)
                                                        {
                                                              tempname = rs.getString(m);
                                                                tempcnt=m-1;
                                                               data[tempcnt] = tempname;
                                                      }
                                                }
                                               defaulttablemodel5.addRow(data);
                                        }
                 }

                       catch(Exception ex3)
                          {
                            System.out.println(""+ex3);
                          }
                 p5.add(new JScrollPane(jtable5,v,h));
                 tabbedPane.addTab(MYPANEL5, p5);

//************************** Complain ****************
 JPanel p6 = new JPanel();
                   p6.setLayout(new GridLayout());
                    p6.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(),"Complainbox"));
                            try
                         {
                    			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
                    			String path="D:\\ty file\\Projects\\Society Administration\\Database.mdb";
                    			String url="jdbc:ucanaccess://"+path;
                    			con=DriverManager.getConnection(url); 				
            Statement statement = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);

//    String query ="SELECT cid as id,fno as FlatNo,complain as Complain FROM complainbox ";// ORDER BY DESC  cid";
String query="Select * FROM complainbox";
                                       ResultSet rs = statement.executeQuery(query);

                                        ResultSetMetaData rmeta = rs.getMetaData();

                                        int numColumns=rmeta.getColumnCount();

                                   for(int n=1;n<=numColumns;++n)
                                       {
                                               if(n<=numColumns)
                                               {
                                                        defaulttablemodel6.addColumn(rmeta.getColumnName(n));
                                                }
                                        }
                                        while(rs.next())
                                        {
                                                for(int n=1;n<=numColumns;++n)
                                               {
                                                        if(n<=numColumns)
                                                        {
                                                              tempname = rs.getString(n);
                                                                tempcnt=n-1;
                                                               data[tempcnt] = tempname;
                                                      }
                                                }
                                               defaulttablemodel6.addRow(data);
                                        }
                 }

                       catch(Exception ex3)
                          {
                            System.out.println(""+ex3);
                          }
                 p6.add(new JScrollPane(jtable6,v,h));
                 tabbedPane.addTab(MYPANEL6, p6);

//************************** 7th ********************
/*JPanel p8 = new JPanel();
                   p8.setLayout(new GridLayout());
 p8.setBackground(new Color(180,159,120));
 
p8.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(),"Owner"));
                            try
                         {

                      Class .forName("sun.jdbc.odbc.JdbcOdbcDriver");
			con=DriverManager.getConnection("jdbc:odbc:database");
			
            Statement statement = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);


    String query ="SELECT oid as Owner_id ,oname as Owner_Name,oeid as Email,mno as Mobile,llno as Landline,nfamily as No_Of_Members  FROM owner";
			
                                       ResultSet rs = statement.executeQuery(query);

                                        ResultSetMetaData rmeta = rs.getMetaData();

                                        int numColumns=rmeta.getColumnCount();

                                   for(int i=1;i<=numColumns;++i)
                                       {
                                               if(i<=numColumns)
                                               {
                                                        defaulttablemodel0.addColumn(rmeta.getColumnName(i));
                                                }
                                        }
                                        while(rs.next())
                                        {
                                                for(int i=1;i<=numColumns;++i)
                                               {
                                                        if(i<=numColumns)
                                                        {
                                                              tempname = rs.getString(i);
                                                                tempcnt=i-1;
                                                               data[tempcnt] = tempname;
                                                      }
                                                }
                                               defaulttablemodel0.addRow(data);
                                        }
                 }

                       catch(Exception ex2)
                          {
                            System.out.println(""+ex2);
                          }
                 p8.add(new JScrollPane(jtable0,v,h));
                 tabbedPane.addTab(MYPANEL0, p8);
*/
 /*    try
                         {

                      Class .forName("sun.jdbc.odbc.JdbcOdbcDriver");
			con=DriverManager.getConnection("jdbc:odbc:database");
			
            Statement statement = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);


    String query ="SELECT oid as Owner_id ,oname as Owner_Name,oeid as Email,mno as Mobile,llno as Landline,nfamily as No_Of_Members  FROM owner";
			
                                       ResultSet rs = statement.executeQuery(query);

                                        ResultSetMetaData rmeta = rs.getMetaData();

                                        int numColumns=rmeta.getColumnCount();

                                   for(int i=1;i<=numColumns;++i)
                                       {
                                               if(i<=numColumns)
                                               {
                                                        defaulttablemodel2.addColumn(rmeta.getColumnName(i));
                                                }
                                        }
                                        while(rs.next())
                                        {
                                                for(int i=1;i<=numColumns;++i)
                                               {
                                                        if(i<=numColumns)
                                                        {
                                                              tempname = rs.getString(i);
                                                                tempcnt=i-1;
                                                               data[tempcnt] = tempname;
                                                      }
                                                }
                                               defaulttablemodel2.addRow(data);
                                        }
                 }

                       catch(Exception ex2)
                          {
                            System.out.println(""+ex2);
                          }
                 p2.add(new JScrollPane(jtable2,v,h));
                 tabbedPane.addTab(MYPANEL2, p2);
*/

 JPanel p7 = new JPanel();
                   p7.setLayout(new GridLayout());
                    p7.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(),"Security"));
                            try
                         {
                    			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
                    			String path="D:\\ty file\\Projects\\Society Administration\\Database.mdb";
                    			String url="jdbc:ucanaccess://"+path;
                    			con=DriverManager.getConnection(url); 				
                      
            Statement statement = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);

    String query ="SELECT * FROM sequrity ";

                                       ResultSet rs = statement.executeQuery(query);

                                        ResultSetMetaData rmeta = rs.getMetaData();

                                        int numColumns=rmeta.getColumnCount();

                                   for(int o=1;o<=numColumns;++o)
                                       {
                                               if(o<=numColumns)
                                               {
                                                        defaulttablemodel7.addColumn(rmeta.getColumnName(o));
                                                }
                                        }
                                        while(rs.next())
                                        {
                                                for(int o=1;o<=numColumns;++o)
                                               {
                                                        if(o<=numColumns)
                                                        {
                                                              tempname = rs.getString(o);
                                                                tempcnt=o-1;
                                                               data[tempcnt] = tempname;
                                                      }
                                                }
                                               defaulttablemodel7.addRow(data);
                                        }
                 }

                       catch(Exception ex3)
                          {
                            System.out.println(""+ex3);
                          }
                 p7.add(new JScrollPane(jtable7,v,h));
                 tabbedPane.addTab(MYPANEL7, p7);

/*/******************* 8th standard ******************
                    JPanel p8 = new JPanel();
                   p8.setLayout(new GridLayout());
                    p8.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(),"8th Standard Student Reports"));
                            try
                         {

                       Class.forName("org.postgresql.Driver");
         Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/pravin","pravin"," " );
            Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);

    String query ="SELECT regno as registerno,admdate as admissiondate,sname as studentname, fname as fathername,suname as surname, stda as standard,div as division, sex as gender, phno as contactnumber,sbdate as birthdate,studfee as studentfees FROM student where stda ="+"'8th'ORDER BY regno";

                                       ResultSet rs = st.executeQuery(query);

                                        ResultSetMetaData rmeta = rs.getMetaData();

                                        int numColumns=rmeta.getColumnCount();

                                   for(int p=1;p<=numColumns;++p)
                                       {
                                               if(p<=numColumns)
                                               {
                                                        defaulttablemodel8.addColumn(rmeta.getColumnName(p));
                                                }
                                        }
                                        while(rs.next())
                                        {
                                                for(int p=1;p<=numColumns;++p)
                                               {
                                                        if(p<=numColumns)
                                                        {
                                                             tempname = rs.getString(p);
                                                                tempcnt=p-1;
                                                               data[tempcnt] = tempname;
                                                      }
                                                }
                                               defaulttablemodel8.addRow(data);
                                        }
                 }

                       catch(Exception ex3)
                          {
                            System.out.println(""+ex3);
                          }
                 p8.add(new JScrollPane(jtable8,v,h));
                 tabbedPane.addTab(MYPANEL8, p8);

// *********************** 9th standard *****************
 JPanel p9 = new JPanel();
                   p9.setLayout(new GridLayout());
                    p9.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(),"9th Standard Student Reports"));
                            try
                         {

                       Class.forName("org.postgresql.Driver");
         Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/pravin","pravin"," " );
            Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);

    String query ="SELECT regno as registerno,admdate as admissiondate,sname as studentname, fname as fathername,suname as surname, stda as standard,div as division, sex as gender, phno as contactnumber,sbdate as birthdate,studfee as studentfees FROM student where stda ="+"'9th'";

                                       ResultSet rs = st.executeQuery(query);

                                        ResultSetMetaData rmeta = rs.getMetaData();

                                        int numColumns=rmeta.getColumnCount();

                                   for(int q=1;q<=numColumns;++q)
                                       {
                                               if(q<=numColumns)
                                               {
                                                        defaulttablemodel9.addColumn(rmeta.getColumnName(q));
                                                }
                                        }
                                        while(rs.next())
                                        {
                                                for(int q=1;q<=numColumns;++q)
                                               {
                                                        if(q<=numColumns)
                                                        {
                                                              tempname = rs.getString(q);
                                                                tempcnt=q-1;
                                                               data[tempcnt] = tempname;
                                                      }
                                                }
                                               defaulttablemodel9.addRow(data);
                                        }
                 }

                       catch(Exception ex3)
                          {
                            System.out.println(""+ex3);
                          }
                 p9.add(new JScrollPane(jtable9,v,h));
                 tabbedPane.addTab(MYPANEL9, p9);
//***************** 10 th standard ******************

 JPanel p10 = new JPanel();
                   p10.setLayout(new GridLayout());
                    p10.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder()," 10th Standard Student Reports"));
                            try
                         {

                       Class.forName("org.postgresql.Driver");
         Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/pravin","pravin"," " );
            Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);

    String query ="SELECT regno as registerno,admdate as admissiondate,sname as studentname, fname as fathername,suname as surname, stda as standard,div as division, sex as gender, phno as contactnumber,sbdate as birthdate,studfee as studentfees FROM student where stda ="+"'10th' ORDER BY regno";

                                       ResultSet rs = st.executeQuery(query);

                                        ResultSetMetaData rmeta = rs.getMetaData();

                                        int numColumns=rmeta.getColumnCount();

                                   for(int w=1;w<=numColumns;++w)
                                       {
                                               if(w<=numColumns)
                                               {
                                                        defaulttablemodel10.addColumn(rmeta.getColumnName(w));
                                                }
                                        }
                                        while(rs.next())
                                        {
                                                for(int w=1;w<=numColumns;++w)
                                               {
                                                        if(w<=numColumns)
                                                        {
                                                              tempname = rs.getString(w);
                                                                tempcnt=w-1;
                                                               data[tempcnt] = tempname;
                                                      }
                                                }
                                               defaulttablemodel10.addRow(data);
                                        }
                 }

                       catch(Exception ex3)
                          {
                            System.out.println(""+ex3);
                          }
                 p10.add(new JScrollPane(jtable10,v,h));
                 tabbedPane.addTab(MYPANEL10, p10);

//*******************total record************
 JPanel p11 = new JPanel();
                   p11.setLayout(new GridLayout());
                    p11.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(),"Overall Student Reports"));
                            try
                         {

                       Class.forName("org.postgresql.Driver");
         Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/pravin","pravin"," " );
            Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);

    String query ="SELECT regno as registerno,admdate as admissiondate,sname as studentname, fname as fathername,suname as surname, stda as standard,div as division,stda as standard, sex as gender, phno as contactnumber,studfee as studentfees FROM student ORDER BY regno ";

                                       ResultSet rs = st.executeQuery(query);

                                        ResultSetMetaData rmeta = rs.getMetaData();

                                        int numColumns=rmeta.getColumnCount();

                                   for(int a=1;a<=numColumns;++a)
                                       {
                                               if(a<=numColumns)
                                               {
                                                        defaulttablemodel11.addColumn(rmeta.getColumnName(a));
                                                }
                                        }
                                        while(rs.next())
                                        {
                                                for(int a=1;a<=numColumns;++a)
                                               {
                                                        if(a<=numColumns)
                                                        {
                                                              tempname = rs.getString(a);
                                                                tempcnt=a-1;
                                                               data[tempcnt] = tempname;
                                                      }
                                                }
                                               defaulttablemodel11.addRow(data);
                                        }
                 }

                       catch(Exception ex3)
                          {
                            System.out.println(""+ex3);
                          }
                 p11.add(new JScrollPane(jtable11,v,h));
                 tabbedPane.addTab(MYPANEL11, p11);*/
                 tabbedPane.setFont(dataFont);
 p3.setBackground(new Color(180,159,120));
// p4.setBackground(new Color(180,159,120));
 p5.setBackground(new Color(180,159,120));
 p6.setBackground(new Color(180,159,120));
 p7.setBackground(new Color(180,159,120));
/* p8.setBackground(new Color(180,159,120));
 p9.setBackground(new Color(180,159,120));
 p10.setBackground(new Color(180,159,120));
 p11.setBackground(new Color(180,159,120));*/

	     } public static void main(String args[])
       {
	       new display();
       }
  }

