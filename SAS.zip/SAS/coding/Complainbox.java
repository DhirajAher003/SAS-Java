import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class Complainbox extends JFrame implements ActionListener
{
	JTextField t1,t2;
	JButton b1,b2;
	TextArea a1;
	JLabel l1,l2,l3,l4,l5;

	Complainbox()
	{
		
		t1 = new JTextField();
		t2 = new JTextField();
		b1 = new JButton("Submit");
		b2=new JButton("Back");
		a1 = new TextArea();
		l1 = new JLabel("Complain Box");
		 l2 = new JLabel("Flat no");
		 l3 = new JLabel("Complain No.");
		 l4 = new JLabel("Write Complain ");
		l5=new JLabel("User Name",new ImageIcon(ClassLoader.getSystemResource("image//pen.jpg")),10);
		
		JScrollPane sp = new JScrollPane(a1);
		add(sp,BorderLayout.CENTER);
			
		add(l1);
		add(l2);	add(t1);
		add(l3);	add(t2);
		add(l4);	add(a1);
		add(b1);	add(b2);
		add(l5);
		setLayout(null);
		l1.setBounds(210,30,200,40);
		l3.setBounds(70,90,150,40);	t1.setBounds(200,90,150,30);
		l2.setBounds(70,140,150,40);	t2.setBounds(200,140,150,30);
		l4.setBounds(70,190,150,40);	a1.setBounds(200,190,250,150);
		b1.setBounds(70,370,80,30);	b2.setBounds(200,370,80,30);
		l5.setBounds(0,0,500,500);  	
		setSize(500,500);
		setVisible(true);
		setLocation(100,100);
		setTitle("Complain Box");


		 b1.addActionListener(this);
		b2.addActionListener(this);
                //this.setDefaultCloseOperation(EXIT_ON_CLOSE);

                Connection con;
                Statement s;
                ResultSet rs;
                int max=0;
                try
                {
        			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        			String path="D:\\ty file\\Projects\\Society Administration\\Database.mdb";
        			String url="jdbc:ucanaccess://"+path;
        			con=DriverManager.getConnection(url); 	
                        s=con.createStatement();
                        rs=s.executeQuery("select max(cno)from complainbox");
                        if(rs.next())
                        {
                                max=rs.getInt(1);
                        }
                        con.close();
                }
                catch(Exception e){}
                max=max+1;
                t1.setText(Integer.toString(max));


        }

        public void actionPerformed(ActionEvent ae)
        {
                Connection con;
                PreparedStatement ps;
                ResultSet rs;

                String temp=ae.getActionCommand();
		 if(temp.equals("Submit"))
                {

                String complain=a1.getText();
                int    fno= Integer.parseInt(t2.getText());
                int    cno=Integer.parseInt(t1.getText());
               
                
                int i=0;

		
                


                        try
                        {
                			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
                			String path="D:\\ty file\\Projects\\Society Administration\\Database.mdb";
                			String url="jdbc:ucanaccess://"+path;
                			con=DriverManager.getConnection(url); 	
                                ps=con.prepareStatement("insert into complainbox values(?,?,?)");
                                ps.setInt(2,fno);
                                ps.setInt(1,cno);
                                ps.setString(3,complain);
                               
                               

                                i=ps.executeUpdate();
                                if(i==1)
                                {
                                        JOptionPane.showMessageDialog(null,"complain inserted","Maintenanace",JOptionPane.INFORMATION_MESSAGE);
                                }




                                con.close();
                        }
                        catch (Exception e)
                        {
                                String s=(e.toString() + e.getMessage());
                        JOptionPane.showMessageDialog(null,s,"Error",JOptionPane.ERROR_MESSAGE);
                        }
                }
		if(temp.equals("Back"))	
		{
			new Other().setVisible(true);
			this.dispose();
		}

		
	}

	public static void main(String a[])
	{
		new Complainbox();
	}
}
