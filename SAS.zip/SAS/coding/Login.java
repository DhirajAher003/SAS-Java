import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;


public class Login extends JFrame implements ActionListener
{
	JLabel l1,l2,l3,l4,l6;
	JTextField t1;
	JPasswordField p;
	//	JComboBox c1;
	JRadioButton r1,r2,r3;
	JButton b1,b2;
	ButtonGroup bg;
	JPanel p1;
	Login()
	{	bg=new ButtonGroup();

		l1=new JLabel("User Name");
		l2=new JLabel("Password");
		l3=new JLabel("Select Option");
		l4=new JLabel("WELLCOME");
		l4.setFont(new Font("Serif",Font.BOLD,20));
                l6=new JLabel("",new ImageIcon(ClassLoader.getSystemResource("image//log.gif")),10);
		b1=new JButton("LOGIN",new ImageIcon(ClassLoader.getSystemResource("image//a.png")));
		b2=new JButton("CANCEL",new ImageIcon(ClassLoader.getSystemResource("image//c.png")));

		t1=new JTextField(10);

		p=new JPasswordField(10);

		bg=new ButtonGroup();

		r1=new JRadioButton("Admin");
		bg.add(r1);
		r2=new JRadioButton("Member");
		bg.add(r2);
		r3=new JRadioButton("Security");
		bg.add(r3);

		setLayout(null);
		l4.setBounds(150,20,200,20);	
		l3.setBounds(60,60,150,20);
		r1.setBounds(60,100,80,20);
		r2.setBounds(140,100,80,20);
		r3.setBounds(220,100,80,20);
		l1.setBounds(60,140,100,20);	t1.setBounds(200,140,100,20);
		l2.setBounds(60,180,100,20);	p.setBounds(200,180,100,20);
		b1.setBounds(60,220,110,25);	b2.setBounds(200,220,110,25);	
		l6.setBounds(0,0,400,400);		

		add(l4);add(l3);add(r1); add(r2); add(r3); add(l1);
		add(l2); add(t1); add(p); add(b1); add(b2);add(l6);
		setVisible(true);
		setSize(400,400);
		setLocation(100,100);
		setTitle("Login");
		r1.setSelected(true);
		b1.addActionListener(this);
		b2.addActionListener(this);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	public void actionPerformed(ActionEvent ae)
	{	String temp1=null;
		Connection con;
		PreparedStatement ps;
		ResultSet rs;

		String temp=ae.getActionCommand();
		String uname=t1.getText();
		//	String pass=p.getText();
		String pass = new String(p.getPassword());

		if (r1.isSelected())
			temp1="admin";
		else if(r2.isSelected())
			temp1=("other");
		else if(r3.isSelected())
			temp1=("security");
		if(temp.equals("LOGIN"))
		{
			if(pass.equals("rushi") && uname.equals("admin")&&temp1.equals("admin"))
			{	
					JOptionPane.showMessageDialog(null,"Admin Login Sucessful","Admin",JOptionPane.INFORMATION_MESSAGE);
						new Admin().setVisible(true);
				this.dispose();
			}
		else	if(pass.equals("roshan") && uname.equals("other")&&temp1.equals("other"))
			{		
				JOptionPane.showMessageDialog(null,"Other Login Sucessful","Other",JOptionPane.INFORMATION_MESSAGE);
				new Other().setVisible(true);
				 this.dispose();

			}	
		else	if(pass.equals("mayur") && uname.equals("security")&&temp1.equals("security"))
			{			new Visitor1().setVisible(true);
						 this.dispose();

			}
						else 
						JOptionPane.showMessageDialog(null,"Invalid username or password","Invalid",JOptionPane.ERROR_MESSAGE);

						}
		else if(temp.equals("CANCEL"))
		{
		 System.exit(0);
		}

						


	}

	public static void main(String a[])
	{
		new Login();
	}
}
